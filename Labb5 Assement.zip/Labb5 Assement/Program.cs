﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb5_Assement
{
    class Program
    {
        static void Main(string[] args)
        {
            Stock stock = new Stock();
            Juice bravo = new Juice() {
                Type = "orange",
                Mark = "Krav",
                Id = 1,
                Name = "Bravo",
                StockCount = 3 };
            Plate flatPlate = new Plate() { Type = "flat", Id = 0, Name = "Flat plate", StockCount = 30 };
            stock.Stockitem[0] = flatPlate;
            stock.Stockitem[1] = bravo;
        }
    }
}
