﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb5_Assement
{
    class Stock
    {
        private StockItem[] stockItem;

        public StockItem[] Stockitem
        {
            get { return stockItem; }
            set { stockItem = value; }
        }

    }
}
